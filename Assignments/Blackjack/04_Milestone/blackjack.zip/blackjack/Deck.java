import java.util.Random;

// This class represents the deck of cards from which cards are dealt to players.
public class Deck
{
	// define fields here
	
	// This constructor builds a deck of 52 cards.
	public Deck()
	{
		// complete this method
	}

	// This method shuffles the deck (randomizes the array of cards).
	// Hint: loop over the cards and swap each one with another card in a random position.
	public void shuffle()
	{
		// complete this method
	}
	
	// This method takes the top card off the deck and returns it.
	public Card drawCard()
	{
		return null; // replace this line with your code
	}
	
	// This method returns the number of cards left in the deck.
	public int getSize()
	{
		return 0; // replace this line with your code
	}
}

